﻿using Microsoft.EntityFrameworkCore;


namespace E_commerce_Website.Models
{
    public class myContext : DbContext
    { public myContext(DbContextOptions<myContext> options) : base(options) { }
    


    public DbSet<Admin> tbl_admin { get; set; }
        public DbSet<customer> tbl_customer { get; set; }
        public DbSet<category> tbl_category { get; set; } 
        public DbSet<product> tbl_product { get; set; }

        public DbSet<cart> tbl_cart { get; set; }

        public DbSet<feedback> tbl_feedback { get; set; }
        public DbSet<faqs> tbl_faqs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<product>().HasOne(p => p.category).WithMany(c => c.products).HasForeignKey(p => p.cat_id);
        }


    }
}