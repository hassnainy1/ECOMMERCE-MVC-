﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace E_commerce_Website.Models
{
    public class cart
    {
        [Key]
        public int cart_Id { get; set; }

    
        public int Pro_id { get; set; }

   
        public int Cust_id { get; set; }

        public int product_Quantity { get; set; }
        public int cart_status { get; set; }

    
}
}
